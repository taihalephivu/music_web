<?php
$conn = new mysqli("localhost", "root", "", "webtintuc");
if ($conn->connect_error) die("Kết nối thất bại: " . $conn->connect_error);
$sql = "SELECT HoTenCS, urlHinhCS, GioiThieuCS FROM webnhac_casi ORDER BY HoTenCS ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách ca sĩ</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 800px; margin: 40px auto; border: 2px solid #222; border-radius: 8px; padding: 24px; background: #f7f7fa; }
        h2 { margin-top: 0; }
        .casi-list { display: flex; flex-wrap: wrap; gap: 24px; }
        .casi-item { width: 230px; background: #fff; border: 1px solid #ccc; border-radius: 8px; padding: 14px; box-sizing: border-box; text-align: center; }
        .casi-item img { width: 120px; height: 120px; object-fit: cover; border-radius: 50%; border: 1px solid #bbb; margin-bottom: 10px; }
        .casi-item h3 { margin: 10px 0 6px 0; font-size: 18px; }
        .casi-item .info { font-size: 14px; color: #444; min-height: 48px; }
        a { display: inline-block; margin-top: 20px; color: #0077cc; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Danh sách ca sĩ</h2>
        <div class="casi-list">
        <?php
        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $img = $row['urlHinhCS'] ? $row['urlHinhCS'] : 'https://via.placeholder.com/120x120?text=No+Image';
                echo '<div class="casi-item">';
                echo '<img src="' . htmlspecialchars($img) . '" alt="' . htmlspecialchars($row['HoTenCS']) . '" onerror="this.onerror=null;this.src=\'https://via.placeholder.com/120x120?text=No+Image\';">';
                echo '<h3>' . htmlspecialchars($row['HoTenCS']) . '</h3>';
                echo '<div class="info">' . ($row['GioiThieuCS'] ? $row['GioiThieuCS'] : '<i>Chưa có thông tin</i>') . '</div>';
                echo '</div>';
            }
        } else {
            echo '<div>Không có dữ liệu ca sĩ</div>';
        }
        ?>
        </div>
        <a href="locbh.php">&laquo; Quay về lọc bài hát</a>
    </div>
</body>
</html>
<?php $conn->close(); ?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webtintuc";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$sql = "SELECT idBH, TenBH FROM webnhac_baihat ORDER BY idBH ASC LIMIT 10";
$result = $conn->query($sql);

echo '<div style="max-width:600px;margin:40px auto;border:2px solid #99c;padding:24px;background:#f7f7fa;border-radius:8px;">';
echo '<h2>Danh sách 10 bài hát đầu</h2>';
echo '<ul style="line-height:2;">';
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo '<li><a href="ctbh.php?idBH=' . $row['idBH'] . '">' . htmlspecialchars($row['TenBH']) . '</a></li>';
    }
} else {
    echo '<li>Không có dữ liệu bài hát</li>';
}
echo '</ul>';
echo '</div>';

$conn->close();
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webtintuc";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Lấy danh sách ca sĩ cho dropdown
$caSiList = [];
$sqlCS = "SELECT idCS, HoTenCS FROM webnhac_casi ORDER BY HoTenCS ASC";
$resultCS = $conn->query($sqlCS);
if ($resultCS && $resultCS->num_rows > 0) {
    while($row = $resultCS->fetch_assoc()) {
        $caSiList[] = $row;
    }
}

// Xử lý lọc
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
$idCS = isset($_GET['idCS']) ? intval($_GET['idCS']) : 0;
$where = [];
if ($keyword != '') {
    $where[] = "TenBH LIKE '%" . $conn->real_escape_string($keyword) . "%'";
}
if ($idCS > 0) {
    $where[] = "idCS = $idCS";
}
$whereSQL = count($where) ? "WHERE " . implode(" AND ", $where) : "";

// Phân trang
$limit = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$start = ($page - 1) * $limit;

// Đếm tổng số bài hát
$sql_count = "SELECT COUNT(*) as total FROM webnhac_baihat $whereSQL";
$result_count = $conn->query($sql_count);
$total = ($result_count && $result_count->num_rows > 0) ? $result_count->fetch_assoc()['total'] : 0;
$total_pages = ceil($total / $limit);

// Lấy danh sách bài hát
$sql = "SELECT idBH, TenBH FROM webnhac_baihat $whereSQL ORDER BY idBH ASC LIMIT $start, $limit";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Lọc bài hát</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { display: flex; max-width: 1000px; margin: 30px auto; border: 2px solid #222; min-height: 600px; }
        .sidebar { width: 200px; border-right: 2px solid #222; padding: 20px 10px; background: #f8f8f8; }
        .sidebar h3 { margin-top: 0; }
        .sidebar ul { list-style: none; padding: 0; }
        .sidebar li { margin-bottom: 10px; }
        .main { flex: 1; padding: 20px; }
        .header { border-bottom: 2px solid #222; padding: 15px 20px; background: #eee; display: flex; justify-content: space-between; align-items: center; }
        .header input[type='text'], .header select { padding: 5px; font-size: 16px; }
        .header button { padding: 6px 12px; font-size: 16px; }
        .songs { margin-top: 30px; }
        .songs table { width: 100%; border-collapse: collapse; }
        .songs th, .songs td { border: 1px solid #aaa; padding: 8px; text-align: left; }
        .songs th { background: #f0f0f0; }
        .pagination { margin: 20px 0; }
        .pagination a, .pagination span { margin: 0 2px; padding: 4px 10px; border: 1px solid #ccc; text-decoration: none; color: #333; }
        .pagination span.current { font-weight: bold; color: red; border-color: red; }
    </style>
</head>
<body>
    <div class="header">
        <div style="font-size:22px;font-weight:bold;">Chọn DS Lọc Bài Hát</div>
        <form method="get" action="" style="margin:0;display:flex;gap:8px;">
            <input type="text" name="keyword" placeholder="Nhập tên bài hát..." value="<?php echo htmlspecialchars($keyword); ?>">
            <select name="idCS">
                <option value="0">-- Chọn ca sĩ --</option>
                <?php foreach($caSiList as $cs): ?>
                    <option value="<?php echo $cs['idCS']; ?>" <?php if($idCS == $cs['idCS']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($cs['HoTenCS']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Lọc</button>
        </form>
    </div>
    <div class="container">
        <div class="sidebar">
            <h3>Menu</h3>
            <ul>
                <li><a href="locbh.php">Web BH</a></li>
                <li><a href="dscasi.php">Web Ca sĩ</a></li>
            </ul>
        </div>
        <div class="main">
            <h2 style="margin-top:0;">DS BH</h2>
            <div class="songs">
                <table>
                    <tr><th>STT</th><th>Tên bài hát</th></tr>
                    <?php
                    if ($result && $result->num_rows > 0) {
                        $stt = $start + 1;
                        while($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . $stt++ . '</td>';
                            echo '<td><a href="ctbh.php?idBH=' . $row['idBH'] . '">' . htmlspecialchars($row['TenBH']) . '</a></td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="2">Không có dữ liệu bài hát</td></tr>';
                    }
                    ?>
                </table>
            </div>
            <div class="pagination">
                <?php
                $range = 2;
                if ($total_pages > 1) {
                    $params = "keyword=" . urlencode($keyword) . "&idCS=" . $idCS;
                    if ($page > 1) {
                        echo "<a href='?$params&page=1'>&laquo;</a> ";
                    }
                    if ($page > $range + 2) {
                        echo "<a href='?$params&page=1'>1</a> ";
                        echo "<span>...</span> ";
                    }
                    for ($i = max(1, $page - $range); $i <= min($total_pages, $page + $range); $i++) {
                        if ($i == $page) {
                            echo "<span class='current'>$i</span> ";
                        } else {
                            echo "<a href='?$params&page=$i'>$i</a> ";
                        }
                    }
                    if ($page < $total_pages - $range - 1) {
                        echo "<span>...</span> ";
                        echo "<a href='?$params&page=$total_pages'>$total_pages</a> ";
                    }
                    if ($page < $total_pages) {
                        echo "<a href='?$params&page=$total_pages'>&raquo;</a> ";
                    }
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>
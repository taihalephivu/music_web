<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webtintuc";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

if (!isset($_GET['idBH'])) {
    echo '<div style="color:red;">Không xác định bài hát!</div>';
    echo '<div style="margin-top:30px;"><a href="dsbh.php">&laquo; Quay lại</a></div>';
    $conn->close();
    exit();
}

$idBH = intval($_GET['idBH']);
$sql = "SELECT TenBH, LoiBH, SoLanNghe, SoLanDown FROM webnhac_baihat WHERE idBH = $idBH";
$result = $conn->query($sql);
echo '<div style="max-width:600px;margin:40px auto;border:2px solid #99c;padding:24px;background:#f7f7fa;border-radius:8px;">';
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo '<h2 style="margin-top:0;">"' . htmlspecialchars($row['TenBH']) . '"</h2>';
    echo '<div style="margin-bottom:12px; color:#333; font-size:15px;">';
    echo 'Số lần nghe: <b>' . intval($row['SoLanNghe']) . '</b><br>';
    echo 'Số lần tải: <b>' . intval($row['SoLanDown']) . '</b>';
    echo '</div>';
    echo '<div style="text-align:center;font-weight:bold;font-size:18px;margin-bottom:10px;">Lời bài hát</div>';
    echo '<div style="margin:20px 0; padding:10px; border:1px solid #ccc; background:#fff; border-radius:4px;">';
    echo $row['LoiBH'] ? $row['LoiBH'] : '<i>Chưa có lời bài hát</i>';
    echo '</div>';
} else {
    echo '<div style="color:red;">Không tìm thấy bài hát!</div>';
}
echo '<div style="margin-top:30px;"><a href="dsbh.php">&laquo; Quay lại</a></div>';
echo '</div>';
$conn->close();
?>

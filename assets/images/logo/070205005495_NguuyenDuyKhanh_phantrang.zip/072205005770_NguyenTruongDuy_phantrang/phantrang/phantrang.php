<?php
include("connect.php");

$sd = 5;

$sql = "SELECT COUNT(*) as total FROM webtm_sanpham";
$result = mysqli_query($link, $sql);
$row = mysqli_fetch_assoc($result);
$total = $row['total'];

$total_pages = ceil($total / $sd);

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
if ($page > $total_pages) $page = $total_pages;

$start = ($page - 1) * $sd;

$sql2 = "SELECT idSP, TenSP, Gia, UrlHinh FROM webtm_sanpham LIMIT $start, $sd";
$result2 = mysqli_query($link, $sql2);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Phân trang sản phẩm</title>
    <style>
        .pagination a, .pagination span {
            margin: 0 3px;
            padding: 3px 8px;
            text-decoration: none;
            border: 1px solid #ccc;
            color: #333;
            display: inline-block;
        }
        .pagination span.current {
            font-weight: bold;
            color: red;
            border-color: red;
        }
        .pagination .dots {
            border: none;
            color: #aaa;
            padding: 3px 5px;
        }
    </style>
</head>
<body>
    <h2>Danh sách sản phẩm (Phân trang)</h2>
    <table border="1" width="600" cellpadding="5" cellspacing="0">
        <tr>
            <th>STT</th>
            <th>Tên sản phẩm</th>
            <th>Hình</th>
            <th>Giá</th>
        </tr>
        <?php
        $stt = $start + 1;
        while ($row = mysqli_fetch_assoc($result2)) {
            echo "<tr>";
            echo "<td>".$stt++."</td>";
            echo "<td>".$row['TenSP']."</td>";
            echo "<td><img src='../".$row['UrlHinh']."' width='100' onerror=\"this.onerror=null;this.src='https://via.placeholder.com/100x100?text=No+Image';\"></td>";
            echo "<td>".$row['Gia']."</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <div class="pagination" style="margin-top:10px;">
        <?php
        $range = 2;
        if ($total_pages > 1) {
            if ($page > 1) {
                echo "<a href='?page=1'>&laquo;</a> ";
            }
            if ($page > $range + 2) {
                echo "<a href='?page=1'>1</a> ";
                echo "<span class='dots'>...</span> ";
            }
            for ($i = max(1, $page - $range); $i <= min($total_pages, $page + $range); $i++) {
                if ($i == $page) {
                    echo "<span class='current'>$i</span> ";
                } else {
                    echo "<a href='?page=$i'>$i</a> ";
                }
            }
            if ($page < $total_pages - $range - 1) {
                echo "<span class='dots'>...</span> ";
                echo "<a href='?page=$total_pages'>$total_pages</a> ";
            }
            if ($page < $total_pages) {
                echo "<a href='?page=$total_pages'>&raquo;</a> ";
            }
        }
        ?>
    </div>
</body>
</html> 
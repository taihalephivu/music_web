<?php
$link = mysqli_connect("localhost", "root", "", "webtintuc"); // "webtintuc" là tên database bạn đã import từ file .sql
if (!$link) {
    die("Không kết nối được MySQL: " . mysqli_connect_error());
}
?>